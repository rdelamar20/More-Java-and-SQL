package com.example.additionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
 import android.view.View;
 import android.widget.Button;
 import android.widget.EditText;
 import android.widget.TextView;

 public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonDoIt = (Button) findViewById(R.id.buttonDoIt);
        buttonDoIt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText editTextNum1 = (EditText) findViewById(R.id.editTextNum1);
                EditText editTextNum2 = (EditText) findViewById(R.id.editTextNum2);
                TextView textViewTotal = (TextView) findViewById(R.id.textViewTotal);

                int num1 = Integer.parseInt(editTextNum1.getText().toString());
                int num2 = Integer.parseInt(editTextNum2.getText().toString());

                int total = num1 + num2;
                textViewTotal.setText(total + "");
            }
        });
    }
}
